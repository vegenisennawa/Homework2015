package Dictionary;

public class MyHahsTable
{
	
}