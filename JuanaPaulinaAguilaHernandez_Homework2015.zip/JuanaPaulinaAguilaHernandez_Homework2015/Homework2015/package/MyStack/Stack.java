package MyStack;

public interface Stack
{
	public boolean empty( );
	public int peek( ) ;
	public void push (int TheObject);
	public int pop( );
}